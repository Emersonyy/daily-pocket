package com.dailypocket.app;
import android.content.*;
public final class BackgroundReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent intent){if(!BackgroundSupport.enabled(c))return;BackgroundSupport.rebind(c);BackgroundSupport.start(c);}
}
