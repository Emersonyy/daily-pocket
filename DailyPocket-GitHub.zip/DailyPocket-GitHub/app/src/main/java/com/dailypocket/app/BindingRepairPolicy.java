package com.dailypocket.app;
public final class BindingRepairPolicy {
 public static final int RETRY=0,REPAIR=1,STOP=2;
 public static int action(int sdk,int attempts,boolean repairUsed){if(sdk>=34&&attempts>=3&&!repairUsed)return REPAIR;if(attempts>=6)return STOP;return RETRY;}
}
