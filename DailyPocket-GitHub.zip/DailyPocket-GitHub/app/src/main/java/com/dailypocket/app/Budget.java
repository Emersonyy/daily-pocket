package com.dailypocket.app;
import java.time.*;
import java.util.*;
import java.math.*;
public final class Budget {
 public static final ZoneId ZONE=ZoneId.of("Asia/Tokyo");
 public static LocalDate today(){return LocalDate.now(ZONE);}
 public static LocalDate monday(LocalDate d){return d.minusDays(d.getDayOfWeek().getValue()-1);}
 public static boolean eligible(LocalDate week, LocalDate today, Set<String> manual){return today.isAfter(week.plusDays(6)) || manual.contains(week.toString());}
 public static long cents(String amount,String rate){return new BigDecimal(amount).multiply(new BigDecimal(rate)).multiply(new BigDecimal("100")).setScale(0,RoundingMode.HALF_UP).longValueExact();}
 public static long dailyDifference(long spent){return 7500-spent;}
 public static long monthBase(YearMonth month,LocalDate start){LocalDate first=month.atDay(1).isAfter(start)?month.atDay(1):start;return first.isAfter(month.atEndOfMonth())?0:java.time.temporal.ChronoUnit.DAYS.between(first,month.atEndOfMonth().plusDays(1))*7500;}
 public static long monthExtra(YearMonth month,LocalDate start,LocalDate today,Set<String>manual){long result=0;for(LocalDate d=month.atDay(1);!d.isAfter(month.atEndOfMonth());d=d.plusDays(1))if(d.getDayOfWeek()==DayOfWeek.SUNDAY && !d.isBefore(start) && eligible(monday(d),today,manual))result+=15000;return result;}
 public static long weekBase(LocalDate week,LocalDate start){LocalDate first=week.isAfter(start)?week:start,end=week.plusDays(6);return first.isAfter(end)?0:Math.multiplyExact(java.time.temporal.ChronoUnit.DAYS.between(first,end)+1,7500L);}
 public static long weekRemaining(LocalDate week,LocalDate start,long spent,boolean extra){return Math.subtractExact(Math.addExact(weekBase(week,start),extra&&!week.plusDays(6).isBefore(start)?15000:0),spent);}
 public static String money(long cents){return BigDecimal.valueOf(cents,2).toPlainString();}
}
