package com.dailypocket.app;
import java.util.*;
public final class DailyGroups {
 public static final class Item{public final String id,date,note;public final long cents;public Item(String id,String date,String note,long cents){this.id=id;this.date=date;this.note=note;this.cents=cents;}}
 public static final class Group{public final String date,note;public long cents;public final List<String>ids=new ArrayList<>();Group(Item i,String scope){date=scope==null?i.date:scope;note=i.note;} }
 public static List<Group> group(List<Item>items){return grouped(items,null);}
 public static List<Group> weekly(List<Item>items){return grouped(items,"所选周");}
 public static List<Group> monthly(List<Item>items){return grouped(items,"所选月");}
 private static List<Group> grouped(List<Item>items,String scope){Map<String,Group>groups=new LinkedHashMap<>();for(Item i:items){boolean category=scope!=null?!i.note.isEmpty():i.note.equals("超市")||i.note.equals("饭");String key=category?(scope!=null?scope+":":i.date+":")+i.note:"id:"+i.id;Group g=groups.get(key);if(g==null){g=new Group(i,scope);groups.put(key,g);}g.cents=Math.addExact(g.cents,i.cents);g.ids.add(i.id);}return new ArrayList<>(groups.values());}
}
