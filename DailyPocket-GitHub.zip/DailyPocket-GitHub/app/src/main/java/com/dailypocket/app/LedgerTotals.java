package com.dailypocket.app;
import java.time.*;import java.util.*;
/** Fixed bills belong to a month; everyday spending belongs to its transaction date. */
public final class LedgerTotals {
 public static final List<String> FIXED=Collections.unmodifiableList(Arrays.asList("房租","电费","gas","话费","交通","其他"));
 public static final class Item {
  public final boolean fixed;public final LocalDate date;public final YearMonth month;public final long cents;
  public Item(String kind,LocalDate date,String billingMonth,long cents){this.fixed="fixed".equals(kind);this.date=date;this.month=fixed?YearMonth.parse(billingMonth):YearMonth.from(date);this.cents=cents;}
 }
 public static long daily(List<Item>items,LocalDate from,LocalDate to){long total=0;for(Item e:items)if(!e.fixed&&!e.date.isBefore(from)&&!e.date.isAfter(to))total=Math.addExact(total,e.cents);return total;}
 public static long fixed(List<Item>items,YearMonth month){long total=0;for(Item e:items)if(e.fixed&&e.month.equals(month))total=Math.addExact(total,e.cents);return total;}
 public static long remaining(List<Item>items,YearMonth month,long base,long extra){return Math.subtractExact(Math.addExact(base,extra),daily(items,month.atDay(1),month.atEndOfMonth()));}
 public static long month(List<Item>items,YearMonth month){return Math.addExact(daily(items,month.atDay(1),month.atEndOfMonth()),fixed(items,month));}
}
