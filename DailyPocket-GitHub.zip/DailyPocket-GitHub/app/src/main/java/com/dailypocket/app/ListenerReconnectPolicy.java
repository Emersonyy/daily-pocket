package com.dailypocket.app;
/** One request in flight; allow Android time to finish binding before another request. */
public final class ListenerReconnectPolicy {
 private int attempts;private long nextAt;
 public boolean acquire(long now,boolean connected){if(connected){reset();return false;}if(now<nextAt)return false;long[]delays={3000,7000,20000,30000,60000,300000};nextAt=now+delays[Math.min(attempts,delays.length-1)];attempts++;return true;}
 public void reset(){attempts=0;nextAt=0;}
 public int attempts(){return attempts;}
 public long delay(long now){return Math.max(0,nextAt-now);}
}
