package com.dailypocket.app;
import java.time.*;import java.time.temporal.ChronoUnit;import java.util.*;
/** Monthly balances accrue daily. Only an explicit cross-month early credit carries a debit. */
public final class MonthlyBudget {
 public static LocalDate through(YearMonth month,LocalDate today){return month.atEndOfMonth().isBefore(today)?month.atEndOfMonth():today;}
 public static long base(YearMonth month,LocalDate start,LocalDate today){LocalDate first=month.atDay(1).isAfter(start)?month.atDay(1):start,end=through(month,today);return first.isAfter(end)?0:Math.multiplyExact(ChronoUnit.DAYS.between(first,end)+1,7500L);}
 public static YearMonth owner(LocalDate week,Map<String,LocalDate> credited){LocalDate at=credited.get(week.toString());return YearMonth.from(at==null?week.plusDays(6):at);}
 public static long extra(YearMonth month,LocalDate start,LocalDate today,Set<String>manual,Map<String,LocalDate> credited){
  if(month.atDay(1).isAfter(today)||month.atEndOfMonth().isBefore(start))return 0;
  long extra=0;
  // A week touching this month is sufficient: neither credits nor debits recur in later months.
  for(LocalDate week=Budget.monday(month.atDay(1));!week.isAfter(month.atEndOfMonth());week=week.plusWeeks(1)){
   LocalDate end=week.plusDays(6);if(end.isBefore(start)||!Budget.eligible(week,today,manual))continue;
   LocalDate at=manual.contains(week.toString())?credited.get(week.toString()):null;
   YearMonth sundayMonth=YearMonth.from(end),creditMonth=at==null?sundayMonth:YearMonth.from(at);
   if(at!=null&&at.isAfter(today))continue;
   if(month.equals(creditMonth))extra=Math.addExact(extra,15000);
   if(at!=null&&creditMonth.isBefore(sundayMonth)&&month.equals(sundayMonth))extra=Math.subtractExact(extra,15000);
  }
  return extra;
 }
 public static long remaining(List<LedgerTotals.Item>items,YearMonth month,LocalDate start,LocalDate today,Set<String>manual,Map<String,LocalDate>credited){return Math.subtractExact(Math.addExact(base(month,start,today),extra(month,start,today,manual,credited)),LedgerTotals.daily(items,month.atDay(1),through(month,today)));}
}
