package com.dailypocket.app;
import java.util.*;
/** Content occurrences in a conversation snapshot survive notification-key/time changes. */
public final class QqDedup {
 public static final class Slot{public final String value;public final int occurrence;public Slot(String v,int n){value=v;occurrence=n;}}
 public static boolean replayRecent(long now,long captured){return now>=captured&&now-captured<10000;}
 public static String value(String body){QqRules.Amount a=QqRules.parse(body);return a==null?null:a.currency+":"+a.amount;}
 public static List<Slot> planSingle(Map<String,Integer> consumed,List<String> evidence,String visible){String key=value(visible);if(key==null)return Collections.emptyList();int old=consumed.getOrDefault(key,0),available=QqRules.counts(evidence).getOrDefault(key,0);if(old>0&&available<=old)return Collections.emptyList();return Collections.singletonList(new Slot(key,old+1));}
 public static List<Slot> plan(Map<String,Integer>consumed,List<String>bodies,String visible){Map<String,Integer> available=new LinkedHashMap<>();for(String body:bodies){String key=value(body);if(key!=null)available.put(key,available.getOrDefault(key,0)+1);}String current=value(visible);List<Slot> result=new ArrayList<>();for(String key:available.keySet()){if(current!=null&&!key.equals(current))continue;int old=consumed.getOrDefault(key,0),count=available.get(key);for(int n=old+1;n<=count;n++){result.add(new Slot(key,n));if(current!=null)break;}}return result;}
}
