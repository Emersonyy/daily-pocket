package com.dailypocket.app;
import android.app.job.*;
/** Recovery is independent of the activity; jobs may be delayed by device power policy. */
public final class QqRecoveryJob extends JobService {
 public boolean onStartJob(JobParameters p){if(BackgroundSupport.enabled(this))BackgroundSupport.rebind(this);return false;}
 public boolean onStopJob(JobParameters p){return true;}
}
