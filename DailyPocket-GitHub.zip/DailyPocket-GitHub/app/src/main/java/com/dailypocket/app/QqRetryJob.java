package com.dailypocket.app;
import android.app.job.*;import org.json.*;
public class QqRetryJob extends JobService {
 public boolean onStartJob(JobParameters p){new Thread(()->{QqProcessor.drain(this);boolean retry=false;try{synchronized(LedgerStore.LOCK){JSONArray a=LedgerStore.read(this).optJSONArray("qqPending");retry=a!=null&&a.length()>0;}}catch(Exception e){retry=true;}jobFinished(p,retry);}).start();return true;}
 public boolean onStopJob(JobParameters p){return true;}
}
