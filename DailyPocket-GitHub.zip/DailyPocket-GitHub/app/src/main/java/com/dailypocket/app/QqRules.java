package com.dailypocket.app;
import java.math.*;import java.text.Normalizer;import java.util.regex.*;import java.util.*;
public final class QqRules {
 public static final String TARGET="夏日漱石";
 public static String cleanSender(String s){return s==null?"":Normalizer.normalize(s,Normalizer.Form.NFKC).trim().replaceFirst("\\s*\\([0-9]+条新消息\\)$","").trim();}
 public static boolean target(String s){return TARGET.equals(cleanSender(s));}
 public static final class Amount{public final String amount,currency,note;Amount(String a,String c,String note){amount=a;currency=c;this.note=note;}}
 public static Amount parse(String raw){if(raw==null||raw.length()>100)return null;String s=Normalizer.normalize(raw,Normalizer.Form.NFKC).trim();Matcher m=Pattern.compile("^(?:(超市|饭)\\s*[:：]?\\s*)?([0-9]+(?:\\.[0-9]{1,2})?)\\s*(人民币|rmb)?$",Pattern.CASE_INSENSITIVE).matcher(s);if(!m.matches())return null;try{BigDecimal n=new BigDecimal(m.group(2));if(n.signum()<=0||n.compareTo(new BigDecimal("1000000000"))>0)return null;return new Amount(n.toPlainString(),m.group(3)==null?"JPY":"CNY",m.group(1)==null?"":m.group(1));}catch(Exception e){return null;}}
 public static String visibleBody(String title,String conversation,boolean group,String text,String bigText){if(group||(!target(title)&&!target(conversation)))return null;for(String raw:new String[]{text,bigText}){String body=lineBody(raw,true);if(parse(body)!=null)return body;}return null;}
 public static String lineBody(String line,boolean knownConversation){if(line==null)return null;String s=Normalizer.normalize(line,Normalizer.Form.NFKC).trim();if(knownConversation&&parse(s)!=null)return s;int colon=s.indexOf(':');if(colon>=0)return target(s.substring(0,colon))?s.substring(colon+1).trim():null;return knownConversation?s:null;}
 /** An expanded snapshot may grow; only occurrences beyond the previous counts are new. */
 public static Map<String,Integer> counts(List<String> bodies){Map<String,Integer> r=new HashMap<>();for(String body:bodies){Amount a=parse(body);if(a!=null){String k=a.currency+":"+a.amount;r.put(k,r.getOrDefault(k,0)+1);}}return r;}
 public static int unseen(int current,int previous){return Math.max(0,current-previous);}
}
