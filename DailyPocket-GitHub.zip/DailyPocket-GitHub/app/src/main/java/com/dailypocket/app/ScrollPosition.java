package com.dailypocket.app;
/** Preserve the last requested offset until the latest rebuilt layout has restored it. */
public final class ScrollPosition {
 private String key="";private int offset;private boolean pending;
 public int begin(String next,int measured){if(!next.equals(key)){offset=0;key=next;}else if(!pending)offset=Math.max(0,measured);pending=true;return offset;}
 public void complete(int actual){offset=Math.max(0,actual);pending=false;}
}
