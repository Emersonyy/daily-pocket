package com.dailypocket.app;
import android.content.*;
import android.app.*;
import java.time.*;
public class SettlementReceiver extends android.content.BroadcastReceiver {
 public void onReceive(Context c,Intent i){schedule(c);}
 public static void schedule(Context c){long next=Budget.today().plusDays(1).atStartOfDay(Budget.ZONE).toInstant().toEpochMilli();PendingIntent p=PendingIntent.getBroadcast(c,1,new Intent(c,SettlementReceiver.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,p);}
}
