package com.dailypocket.app;
import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;
public final class SwipeEntry extends FrameLayout {
 private final TextView content;private final LinearLayout actions;private final int reveal;private final SwipeGesture gesture;private boolean dragging,actionTouch;
 private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
 public SwipeEntry(Context c,String label,String secondary,Runnable edit,Runnable remark,Runnable delete){
  super(c);reveal=dp(160);gesture=new SwipeGesture(ViewConfiguration.get(c).getScaledTouchSlop());setClipChildren(true);
  actions=new LinearLayout(c);Button note=new Button(c),remove=new Button(c);note.setText("备注");remove.setText("删除");note.setTextColor(Color.WHITE);remove.setTextColor(Color.WHITE);note.setBackgroundColor(Color.rgb(22,103,91));remove.setBackgroundColor(Color.rgb(230,85,85));actions.addView(note,new LinearLayout.LayoutParams(dp(80),-1));actions.addView(remove,new LinearLayout.LayoutParams(dp(80),-1));addView(actions,new FrameLayout.LayoutParams(reveal,-1,Gravity.RIGHT));
  content=new TextView(c);android.text.SpannableString styled=new android.text.SpannableString(label+(secondary.isEmpty()?"":"\n"+secondary));styled.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),0,label.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);if(!secondary.isEmpty()){int start=label.length()+1;styled.setSpan(new android.text.style.AbsoluteSizeSpan(13,true),start,styled.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);styled.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.NORMAL),start,styled.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);styled.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(100,100,100)),start,styled.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
  content.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL));content.setText(styled);content.setTextColor(Color.BLACK);content.setTextSize(21);content.setBackgroundColor(Color.WHITE);content.setPadding(0,dp(12),dp(12),dp(12));content.setMinHeight(dp(64));content.setGravity(Gravity.CENTER_VERTICAL);addView(content,new FrameLayout.LayoutParams(-1,-2));setMinimumHeight(dp(64));
  note.setOnClickListener(v->{close();remark.run();});remove.setOnClickListener(v->{close();delete.run();});content.setOnClickListener(v->{if(content.getTranslationX()!=0)close();else edit.run();});
  content.setOnLongClickListener(v->{PopupMenu p=new PopupMenu(c,content);p.getMenu().add("备注");p.getMenu().add("删除");p.setOnMenuItemClickListener(item->{if(item.getTitle().equals("备注"))remark.run();else delete.run();return true;});p.show();return true;});content.setContentDescription(label+"，左滑显示备注和删除");
 }
 // Measure the revealed controls to the row's actual height, including on short, non-scrolling pages.
 @Override protected void onMeasure(int widthSpec,int heightSpec){super.onMeasure(widthSpec,heightSpec);actions.measure(MeasureSpec.makeMeasureSpec(reveal,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(getMeasuredHeight(),MeasureSpec.EXACTLY));}
 @Override public boolean onInterceptTouchEvent(android.view.MotionEvent e){
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    content.animate().cancel();dragging=false;actionTouch=content.getTranslationX()<0&&e.getX()>=getWidth()+content.getTranslationX();
    gesture.down(e.getRawX(),e.getRawY(),content.getTranslationX());
    // Reserve the first move so ScrollView cannot cancel us before direction is known.
    getParent().requestDisallowInterceptTouchEvent(true);return false;
   case MotionEvent.ACTION_MOVE:
    if(actionTouch)return false;int direction=gesture.move(e.getRawX(),e.getRawY());
    if(direction==SwipeGesture.VERTICAL){getParent().requestDisallowInterceptTouchEvent(false);return false;}
    if(direction==SwipeGesture.HORIZONTAL){dragging=true;return true;}return false;
   case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:getParent().requestDisallowInterceptTouchEvent(false);return false;
   default:return false;
  }
 }
 @Override public boolean onTouchEvent(MotionEvent e){
  if(!dragging)return super.onTouchEvent(e);
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_MOVE:content.setTranslationX(gesture.position(e.getRawX(),reveal));return true;
   case MotionEvent.ACTION_UP:content.animate().translationX(gesture.open(e.getRawX())?-reveal:0).setDuration(140).start();dragging=false;getParent().requestDisallowInterceptTouchEvent(false);return true;
   case MotionEvent.ACTION_CANCEL:content.animate().translationX(gesture.origin()).setDuration(140).start();dragging=false;getParent().requestDisallowInterceptTouchEvent(false);return true;
   default:return true;
  }
 }
 private void close(){content.animate().translationX(0).setDuration(140).start();}
}
