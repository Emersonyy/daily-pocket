package com.dailypocket.app;
/** Direction locking keeps small vertical drift from turning a horizontal action into scrolling. */
public final class SwipeGesture {
 public static final int PENDING=0,HORIZONTAL=1,VERTICAL=2;
 private final float slop;private float downX,downY,origin;private int direction;
 public SwipeGesture(float slop){this.slop=slop;}
 public void down(float x,float y,float translation){downX=x;downY=y;origin=translation;direction=PENDING;}
 public int move(float x,float y){if(direction==PENDING){float dx=Math.abs(x-downX),dy=Math.abs(y-downY);if(dx>slop&&dx>=dy)direction=HORIZONTAL;else if(dy>slop)direction=VERTICAL;}return direction;}
 public float position(float x,float reveal){return Math.max(-reveal,Math.min(0,origin+x-downX));}
 public boolean open(float x){return origin==0?x-downX<-slop:x-downX<=slop;}
 public float origin(){return origin;}
}
