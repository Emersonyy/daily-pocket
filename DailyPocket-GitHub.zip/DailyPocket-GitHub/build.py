"""Build native Android APK without Gradle. Requires JDK17 and SDK platform/build-tools35."""
import argparse,os,pathlib,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('--jdk',required=True);p.add_argument('--platform',required=True);p.add_argument('--tools',required=True);p.add_argument('--out',required=True);p.add_argument('--keystore',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent;out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
jdk=pathlib.Path(a.jdk).resolve();sdk=pathlib.Path(a.tools).resolve();platform=pathlib.Path(a.platform).resolve();env=os.environ.copy();env['JAVA_HOME']=str(jdk);env['PATH']=str(jdk/'bin')+os.pathsep+env['PATH']
def run(*x):subprocess.run([str(v) for v in x],check=True,env=env)
main=root/'app/src/main';classes=out/'classes';classes.mkdir(exist_ok=True);dex=out/'dex';dex.mkdir(exist_ok=True)
run(sdk/'aapt2','compile','--dir',main/'res','-o',out/'res.zip')
run(sdk/'aapt2','link','-o',out/'unsigned.apk','--manifest',main/'AndroidManifest.xml','-I',platform,'--min-sdk-version','26','--target-sdk-version','35',out/'res.zip')
run(jdk/'bin/javac','-encoding','UTF-8','--release','8','-classpath',platform,'-d',classes,*main.glob('java/com/dailypocket/app/*.java'))
run(sdk/'d8','--min-api','26','--lib',platform,'--output',dex,*classes.rglob('*.class'))
with zipfile.ZipFile(out/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in dex.glob('*.dex'):z.write(f,f.name)
run(sdk/'zipalign','-f','-p','4',out/'unsigned.apk',out/'aligned.apk')
key=pathlib.Path(a.keystore).resolve()
if not key.exists():
 key.parent.mkdir(parents=True,exist_ok=True)
 run(jdk/'bin/keytool','-genkeypair','-keystore',key,'-alias','daily-pocket','-keyalg','RSA','-keysize','2048','-validity','10000','-storepass','android','-keypass','android','-dname','CN=Daily Pocket Local Build')
 key.chmod(0o600)
run(sdk/'apksigner','sign','--ks',key,'--ks-key-alias','daily-pocket','--ks-pass','pass:android','--key-pass','pass:android','--out',out/'DailyPocket.apk',out/'aligned.apk')
run(sdk/'apksigner','verify','--verbose',out/'DailyPocket.apk')
print('APK:',out/'DailyPocket.apk')
