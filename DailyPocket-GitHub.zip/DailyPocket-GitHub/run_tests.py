"""Run the project's JVM-only regression checks with JDK 17."""
import argparse
import pathlib
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--jdk", required=True, help="JDK home containing bin/java and bin/javac")
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent
jdk = pathlib.Path(args.jdk).expanduser().resolve() / "bin"
suffix = ".exe" if __import__("os").name == "nt" else ""
source = root / "app/src/main/java/com/dailypocket/app"
output = root / "build/tests"
output.mkdir(parents=True, exist_ok=True)
names = ["Budget", "LedgerTotals", "MonthlyBudget", "DailyGroups", "QqRules", "QqDedup", "ScrollPosition", "ListenerReconnectPolicy", "BindingRepairPolicy", "SwipeGesture"]
tests = sorted((root / "tests").glob("*.java"))
subprocess.run([str(jdk / ("javac" + suffix)), "--release", "8", "-encoding", "UTF-8", "-d", str(output), *[str(source / (name + ".java")) for name in names], *[str(test) for test in tests]], check=True)
for test in tests:
    subprocess.run([str(jdk / ("java" + suffix)), "-cp", str(output), test.stem], check=True)
