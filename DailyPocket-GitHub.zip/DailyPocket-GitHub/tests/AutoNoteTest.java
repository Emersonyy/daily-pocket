import com.dailypocket.app.*;import java.util.*;
public class AutoNoteTest{
 static int n;static void eq(Object a,Object b){n++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static void check(String input,String amount,String currency,String note){QqRules.Amount a=QqRules.parse(input);eq(a.amount,amount);eq(a.currency,currency);eq(a.note,note);}
 public static void main(String[]args){check("超市288","288","JPY","超市");check("饭23.86rmb","23.86","CNY","饭");check("超市23.86人民币","23.86","CNY","超市");check("饭：288","288","JPY","饭");check("超市 288 RMB","288","CNY","超市");check("288","288","JPY","");check("23.86rmb","23.86","CNY","");eq(QqRules.parse("交通288"),null);eq(QqRules.parse("午饭288"),null);eq(QqRules.visibleBody("夏日漱石","",false,"超市288",""),"超市288");eq(QqRules.counts(Arrays.asList("饭288","超市288")).get("JPY:288"),2);eq(QqRules.visibleBody("夏日漱石","",false,"饭：288",""),"饭:288");eq(Budget.dailyDifference(6047),1453L);eq(Budget.dailyDifference(8000),-500L);eq(Budget.dailyDifference(0),7500L);System.out.println(n+" automatic-note and balance assertions passed");}
}
