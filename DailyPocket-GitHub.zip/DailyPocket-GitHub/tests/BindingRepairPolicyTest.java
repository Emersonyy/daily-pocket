import com.dailypocket.app.BindingRepairPolicy;
public class BindingRepairPolicyTest{
 static int n;static void eq(int a,int b){n++;if(a!=b)throw new AssertionError(a+" != "+b);}
 public static void main(String[]args){eq(BindingRepairPolicy.action(34,0,false),0);eq(BindingRepairPolicy.action(34,2,false),0);eq(BindingRepairPolicy.action(34,3,false),1);eq(BindingRepairPolicy.action(35,6,false),1);eq(BindingRepairPolicy.action(35,3,true),0);eq(BindingRepairPolicy.action(35,6,true),2);eq(BindingRepairPolicy.action(33,3,false),0);eq(BindingRepairPolicy.action(33,6,false),2);eq(BindingRepairPolicy.action(36,100,true),2);System.out.println(n+" binding-repair policy assertions passed");}
}
