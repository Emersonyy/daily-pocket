import com.dailypocket.app.Budget;import java.time.*;import java.util.*;
public class BudgetTest{
 static int n=0;static void eq(Object a,Object b){n++;if(!a.equals(b))throw new AssertionError(a+" != "+b);}
 public static void main(String[]args){
 eq(Budget.dailyDifference(6000),1500L);eq(Budget.dailyDifference(7500),0L);eq(Budget.dailyDifference(10000),-2500L);
 eq(Budget.cents("1000","0.04225"),4225L);eq(Budget.cents("0.10","1"),10L);eq(Budget.cents("1","0.045"),5L);
 LocalDate w=LocalDate.of(2026,9,28);eq(Budget.monday(LocalDate.of(2026,10,4)),w);
 Set<String>s=new HashSet<>();eq(Budget.eligible(w,LocalDate.of(2026,10,4),s),false);eq(Budget.eligible(w,LocalDate.of(2026,10,5),s),true);
 s.add(w.toString());s.add(w.toString());eq(Budget.eligible(w,LocalDate.of(2026,10,1),s),true);
 LocalDate start=LocalDate.of(2026,9,1);eq(Budget.monthExtra(YearMonth.of(2026,10),start,LocalDate.of(2026,10,1),s),15000L);
 eq(Budget.monthExtra(YearMonth.of(2026,9),start,LocalDate.of(2026,10,1),s),60000L);
 eq(Budget.monthExtra(YearMonth.of(2026,10),start,LocalDate.of(2026,11,1),s),60000L);
 eq(Budget.monthBase(YearMonth.of(2026,10),start),232500L);
 eq(Budget.monthBase(YearMonth.of(2026,10),LocalDate.of(2026,10,12)),150000L);
 eq(Budget.monthBase(YearMonth.of(2026,9),LocalDate.of(2026,10,12)),0L);
 eq(Budget.monthBase(YearMonth.of(2028,2),LocalDate.of(2028,2,1)),217500L);
 eq(Budget.monthExtra(YearMonth.of(2026,10),LocalDate.of(2026,10,12),LocalDate.of(2026,11,1),new HashSet<>()),30000L);
 eq(Budget.money(-1500),"-15.00");System.out.println(n+" budget assertions passed");}
}
