import com.dailypocket.app.*;import java.util.*;
public class DailyGroupsTest{
 static int n;static void eq(Object a,Object b){n++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static DailyGroups.Item i(String id,String date,String note,long c){return new DailyGroups.Item(id,date,note,c);}
 public static void main(String[]args){List<DailyGroups.Item>items=new ArrayList<>(Arrays.asList(i("a","2026-10-13","饭",2836),i("b","2026-10-13","超市",1215),i("c","2026-10-13","超市",3211),i("d","2026-10-14","超市",1000),i("e","2026-10-13","",500),i("f","2026-10-13","",200)));List<DailyGroups.Group>groups=DailyGroups.group(items);eq(groups.size(),5);eq(groups.get(1).cents,4426L);eq(groups.get(1).ids,Arrays.asList("b","c"));eq(groups.get(2).cents,1000L);eq(groups.get(0).cents,2836L);items.add(i("g","2026-10-13","超市",236));eq(DailyGroups.group(items).get(1).cents,4662L);items.removeIf(x->x.id.equals("c"));eq(DailyGroups.group(items).get(1).cents,1451L);eq(items.size(),6);System.out.println(n+" daily grouping assertions passed");}
}
