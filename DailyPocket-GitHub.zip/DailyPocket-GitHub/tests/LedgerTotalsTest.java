import com.dailypocket.app.*;import java.time.*;import java.util.*;
public class LedgerTotalsTest{
 static int n=0;static void eq(Object actual,Object expected){n++;if(!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
 static LedgerTotals.Item e(String kind,String date,String month,long cents){return new LedgerTotals.Item(kind,LocalDate.parse(date),month,cents);}
 public static void main(String[] args){YearMonth oct=YearMonth.of(2026,10);List<LedgerTotals.Item>items=new ArrayList<>();
 // Old version rows have no kind. They remain daily spending.
 items.add(e("","2026-10-01","",6000));items.add(e("daily","2026-10-01","",1500));items.add(e("daily","2026-10-02","",4200));items.add(e("fixed","2026-10-01","2026-10",132242));items.add(e("fixed","2026-10-12","2026-10",16856));items.add(e("fixed","2026-09-30","2026-09",90000));items.add(e("daily","2026-09-30","",1000));
 eq(LedgerTotals.daily(items,LocalDate.of(2026,10,1),LocalDate.of(2026,10,1)),7500L);
 eq(Budget.dailyDifference(LedgerTotals.daily(items,LocalDate.of(2026,10,1),LocalDate.of(2026,10,1))),0L);
 eq(LedgerTotals.daily(items,LocalDate.of(2026,9,28),LocalDate.of(2026,10,4)),12700L);
 eq(LedgerTotals.fixed(items,oct),149098L);eq(LedgerTotals.month(items,oct),160798L);
 eq(LedgerTotals.remaining(items,oct,232500,15000),235800L);
 // Adding an arbitrary fixed bill must not change any target or budget calculation.
 items.add(e("fixed","2026-10-12","2026-10",10000000));
 eq(LedgerTotals.daily(items,LocalDate.of(2026,10,1),LocalDate.of(2026,10,31)),11700L);
 eq(LedgerTotals.remaining(items,oct,232500,15000),235800L);eq(LedgerTotals.month(items,oct),10160798L);
 eq(LedgerTotals.fixed(items,YearMonth.of(2026,9)),90000L);
 eq(LedgerTotals.month(items,YearMonth.of(2026,9)),91000L);
 items.add(e("daily","2026-10-12","",300000));eq(LedgerTotals.remaining(items,oct,232500,15000),-64200L);
 eq(LedgerTotals.FIXED,Arrays.asList("房租","电费","gas","话费","交通","其他"));
 eq(LedgerTotals.month(Collections.emptyList(),YearMonth.of(2026,11)),0L);
 eq(YearMonth.of(2026,10).lengthOfMonth(),31);eq(YearMonth.of(2028,2).lengthOfMonth(),29);
 System.out.println(n+" ledger assertions passed");}
}
