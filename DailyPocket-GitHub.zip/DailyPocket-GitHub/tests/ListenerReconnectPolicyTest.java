import com.dailypocket.app.ListenerReconnectPolicy;
public class ListenerReconnectPolicyTest{
 static int n;static void eq(long a,long b){n++;if(a!=b)throw new AssertionError(a+" != "+b);}static void yes(boolean a){n++;if(!a)throw new AssertionError();}
 public static void main(String[]args){ListenerReconnectPolicy p=new ListenerReconnectPolicy();yes(p.acquire(0,false));eq(p.attempts(),1);yes(!p.acquire(1,false));eq(p.delay(1000),2000);yes(!p.acquire(2999,false));yes(p.acquire(3000,false));eq(p.attempts(),2);eq(p.delay(3000),7000);yes(!p.acquire(9999,false));yes(p.acquire(10000,false));eq(p.delay(10000),20000);yes(p.acquire(30000,false));eq(p.delay(30000),30000);yes(!p.acquire(31000,false));yes(!p.acquire(31000,true));eq(p.attempts(),0);yes(p.acquire(32000,false));eq(p.delay(32000),3000);p.reset();yes(p.acquire(40000,false));eq(p.attempts(),1);System.out.println(n+" listener recovery assertions passed");}
}
