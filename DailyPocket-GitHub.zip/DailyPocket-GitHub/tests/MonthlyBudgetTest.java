import com.dailypocket.app.*;import java.time.*;import java.util.*;
public class MonthlyBudgetTest {
 static int n;static void eq(Object actual,Object expected){n++;if(!Objects.equals(actual,expected))throw new AssertionError(actual+" != "+expected);}
 static LocalDate d(String s){return LocalDate.parse(s);}static YearMonth m(String s){return YearMonth.parse(s);}
 public static void main(String[] args){
  LocalDate start=d("2026-09-01");Set<String>manual=new HashSet<>();Map<String,LocalDate>dates=new HashMap<>();List<LedgerTotals.Item>items=new ArrayList<>();
  eq(MonthlyBudget.base(m("2026-10"),start,d("2026-10-01")),7500L);
  eq(MonthlyBudget.base(m("2026-10"),start,d("2026-10-02")),15000L);
  eq(MonthlyBudget.base(m("2026-10"),start,d("2026-10-16")),120000L);
  eq(MonthlyBudget.base(m("2026-10"),d("2026-10-12"),d("2026-10-16")),37500L);
  eq(MonthlyBudget.base(m("2026-11"),start,d("2026-10-16")),0L);
  eq(MonthlyBudget.remaining(items,m("2026-11"),start,d("2026-10-16"),manual,dates),0L);
  eq(MonthlyBudget.base(m("2026-09"),start,d("2026-10-16")),225000L);
  eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-04"),manual,dates),0L);
  eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-05"),manual,dates),15000L);
  // Prior two weeks -80, current week -10; no future weekend budget or fixed bills.
  items.add(new LedgerTotals.Item("daily",d("2026-10-04"),"",53000));
  items.add(new LedgerTotals.Item("daily",d("2026-10-11"),"",67500));
  items.add(new LedgerTotals.Item("daily",d("2026-10-16"),"",38500));
  items.add(new LedgerTotals.Item("fixed",d("2026-10-01"),"2026-10",130000));
  eq(MonthlyBudget.remaining(items,m("2026-10"),start,d("2026-10-16"),manual,dates),-9000L);
  manual.add("2026-10-12");dates.put("2026-10-12",d("2026-10-16"));
  eq(MonthlyBudget.remaining(items,m("2026-10"),start,d("2026-10-16"),manual,dates),6000L);
  eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-19"),manual,dates),45000L);
  // Sep30 early credit: September +150, October -150, never restored on Oct5.
  manual.clear();dates.clear();items.clear();manual.add("2026-09-28");dates.put("2026-09-28",d("2026-09-30"));
  eq(MonthlyBudget.owner(d("2026-09-28"),dates),m("2026-09"));
  eq(MonthlyBudget.extra(m("2026-09"),start,d("2026-09-30"),manual,dates),75000L);
  eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-01"),manual,dates),-15000L);
  eq(MonthlyBudget.remaining(items,m("2026-10"),start,d("2026-10-01"),manual,dates),-7500L);
  eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-05"),manual,dates),-15000L);
  eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-12"),manual,dates),0L);
  eq(MonthlyBudget.extra(m("2026-11"),start,d("2026-11-02"),manual,dates),15000L);
  // Historical app versions did not retain activation dates: retain Sunday allocation.
  dates.clear();eq(MonthlyBudget.extra(m("2026-10"),start,d("2026-10-01"),manual,dates),15000L);
  eq(MonthlyBudget.extra(m("2026-09"),start,d("2026-10-01"),manual,dates),60000L);
  // Year rollover and leap-month accrual.
  manual.clear();dates.clear();manual.add("2026-12-28");dates.put("2026-12-28",d("2026-12-31"));
  eq(MonthlyBudget.extra(m("2027-01"),start,d("2027-01-04"),manual,dates),-15000L);
  eq(MonthlyBudget.base(m("2028-02"),start,d("2028-03-01")),217500L);
  eq(MonthlyBudget.extra(m("2026-08"),start,d("2026-10-16"),manual,dates),0L);
  System.out.println(n+" monthly budget assertions passed");
 }
}
