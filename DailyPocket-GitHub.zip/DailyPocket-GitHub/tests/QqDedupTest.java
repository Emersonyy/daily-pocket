import com.dailypocket.app.*;import java.util.*;
public class QqDedupTest{
 static int n=0;static void check(boolean ok){n++;if(!ok)throw new AssertionError("case "+n);}
 static int apply(Map<String,Integer>seen,List<String>snapshot,String visible){List<QqDedup.Slot>slots=QqDedup.plan(seen,snapshot,visible);for(QqDedup.Slot s:slots)seen.put(s.value,s.occurrence);return slots.size();}
 public static void main(String[]args){Map<String,Integer>seen=new HashMap<>();List<String>batch=Arrays.asList("761","288");check(apply(seen,batch,"761")==1);check(seen.get("JPY:761")==1&&!seen.containsKey("JPY:288"));check(apply(seen,batch,"761")==0);check(apply(seen,batch,"288")==1);check(apply(seen,batch,"288")==0);check(apply(seen,batch,"")==0);check(seen.get("JPY:761")==1&&seen.get("JPY:288")==1);
 // The next real same-valued message is represented by another occurrence in the snapshot.
 check(apply(seen,Arrays.asList("761","288","761"),"761")==1);check(seen.get("JPY:761")==2);check(apply(seen,Arrays.asList("761","288","761"),"761")==0);
 seen.clear();check(apply(seen,batch,"")==2);check(apply(seen,batch,"")==0);check(apply(seen,batch,"761")==0);check(apply(seen,Arrays.asList("288","761"),"")==0);check(apply(seen,Arrays.asList("288"),"")==0);
 seen.clear();check(apply(seen,Arrays.asList("3.82人民币","3.84rmb"),"")==2);check(apply(seen,Arrays.asList("3.82rmb","3.84人民币"),"")==0);check(QqDedup.value("普通聊天")==null);check(apply(seen,Arrays.asList("761","288","普通聊天"),"761")==1);System.out.println(n+" replay regression assertions passed");}
}
