import com.dailypocket.app.QqRules;import java.util.*;
public class QqRulesTest{
 static int n=0;static void eq(Object a,Object b){n++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static void money(String text,String amount,String currency){QqRules.Amount a=QqRules.parse(text);eq(a==null?null:a.amount,amount);eq(a==null?null:a.currency,currency);}
 public static void main(String[]args){money("800","800","JPY");money("3.82人民币","3.82","CNY");money("3.84rmb","3.84","CNY");money("3.84RMB","3.84","CNY");money("  100 人民币  ","100","CNY");money("１００","100","JPY");money("00100","100","JPY");for(String invalid:new String[]{"你好","800日元","午饭800","3.82rmb测试","-10","0","1,000","1e3","1.234","1\n2","2条新消息","1000000001"})eq(QqRules.parse(invalid),null);
 eq(QqRules.target("夏日漱石"),true);eq(QqRules.target("夏日漱石(2条新消息)"),true);eq(QqRules.target("夏日漱石（2条新消息）"),true);eq(QqRules.target("夏日漱石朋友"),false);eq(QqRules.target("张三"),false);
 eq(QqRules.lineBody("夏日漱石：800",false),"800");eq(QqRules.lineBody("张三：800",true),null);eq(QqRules.lineBody("800",false),null);eq(QqRules.lineBody("800",true),"800");
 Map<String,Integer> prev=QqRules.counts(Arrays.asList("100","3人民币"));Map<String,Integer> now=QqRules.counts(Arrays.asList("100","3人民币","100"));eq(prev.get("JPY:100"),1);eq(now.get("JPY:100"),2);eq(QqRules.unseen(now.get("JPY:100"),prev.get("JPY:100")),1);eq(QqRules.unseen(1,1),0);eq(QqRules.unseen(1,2),0);eq(QqRules.unseen(3,1),2);
 System.out.println(n+" QQ rule assertions passed");}
}
