import com.dailypocket.app.*;
public class SwipeGestureTest {
 static int n;static void eq(Object a,Object b){n++;if(!a.equals(b))throw new AssertionError(a+" != "+b);}
 public static void main(String[]args){SwipeGesture g=new SwipeGesture(8);g.down(200,100,0);eq(g.move(196,103),SwipeGesture.PENDING);eq(g.move(187,104),SwipeGesture.HORIZONTAL);eq(g.position(187,160),-13f);eq(g.open(187),true);eq(g.position(-100,160),-160f);eq(g.move(186,140),SwipeGesture.HORIZONTAL);g.down(200,100,0);eq(g.move(196,115),SwipeGesture.VERTICAL);eq(g.move(100,115),SwipeGesture.VERTICAL);eq(g.open(200),false);g.down(200,100,-160);eq(g.move(220,102),SwipeGesture.HORIZONTAL);eq(g.position(220,160),-140f);eq(g.open(220),false);g.down(200,100,-160);eq(g.open(197),true);eq(g.origin(),-160f);g.down(200,100,0);eq(g.position(260,160),0f);System.out.println(n+" swipe-direction assertions passed");}
}
