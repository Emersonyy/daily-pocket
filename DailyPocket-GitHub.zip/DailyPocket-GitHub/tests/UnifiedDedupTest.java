import com.dailypocket.app.*;import java.util.*;
public class UnifiedDedupTest{
 static int n;static void eq(Object a,Object b){n++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static int apply(Map<String,Integer>state,List<QqDedup.Slot>slots){for(QqDedup.Slot s:slots)state.put(s.value,s.occurrence);return slots.size();}
 public static void main(String[]args){Map<String,Integer>seen=new HashMap<>();List<String>none=Collections.emptyList(),both=Arrays.asList("781","288");
 // 288 arrives early as a single callback, then the full list, then another single echo.
 eq(apply(seen,QqDedup.planSingle(seen,none,"288")),1);eq(apply(seen,QqDedup.plan(seen,both,"")),1);eq(apply(seen,QqDedup.planSingle(seen,none,"288")),0);eq(seen.get("JPY:288"),1);eq(seen.get("JPY:781"),1);
 seen.clear();eq(apply(seen,QqDedup.plan(seen,both,"")),2);eq(apply(seen,QqDedup.planSingle(seen,none,"288")),0);
 seen.clear();eq(apply(seen,QqDedup.planSingle(seen,both,"781")),1);eq(apply(seen,QqDedup.planSingle(seen,both,"288")),1);eq(apply(seen,QqDedup.planSingle(seen,both,"288")),0);
 eq(apply(seen,QqDedup.planSingle(seen,Arrays.asList("781","288","288"),"288")),1);eq(seen.get("JPY:288"),2);seen.clear();eq(apply(seen,QqDedup.planSingle(seen,none,"288")),1);
 eq(Budget.cents("781","0.0422")+Budget.cents("288","0.0422"),4511L);System.out.println(n+" unified notification regression assertions passed");}
}
