import com.dailypocket.app.*;import java.util.*;
public class VisibleBodyTest{
 static int n;static void eq(Object a,Object b){n++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 public static void main(String[]x){eq(QqRules.visibleBody("夏日漱石","",false,"288",""),"288");eq(QqRules.visibleBody("夏日漱石(2条新消息)","",false,"761","288"),"761");eq(QqRules.visibleBody("夏日漱石","",false,"夏日漱石：288",""),"288");eq(QqRules.visibleBody("夏日漱石","",false,"","288"),"288");eq(QqRules.visibleBody("QQ","夏日漱石",false,"3.82人民币",""),"3.82人民币");eq(QqRules.visibleBody("张三","",false,"288",""),null);eq(QqRules.visibleBody("夏日漱石","",true,"288",""),null);eq(QqRules.visibleBody("夏日漱石","",false,"张三：288",""),null);eq(QqRules.visibleBody("夏日漱石","",false,"2条新消息",""),null);System.out.println(n+" visible-body assertions passed");}
}
