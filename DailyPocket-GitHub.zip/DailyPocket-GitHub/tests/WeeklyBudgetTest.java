import com.dailypocket.app.*;import java.time.*;
public class WeeklyBudgetTest {
 static int n;static void eq(long actual,long expected){n++;if(actual!=expected)throw new AssertionError(actual+" != "+expected);}
 public static void main(String[]args){LocalDate week=LocalDate.of(2026,10,12),start=LocalDate.of(2026,10,1);eq(Budget.weekBase(week,start),52500);eq(Budget.weekRemaining(week,start,22173,true),45327);eq(Budget.weekRemaining(week,start,22173,false),30327);eq(Budget.weekRemaining(week,start,70000,true),-2500);eq(Budget.weekRemaining(week,start,67500,true),0);eq(Budget.weekBase(LocalDate.of(2026,9,28),start),30000);eq(Budget.weekBase(LocalDate.of(2026,9,21),start),0);eq(Budget.weekRemaining(LocalDate.of(2026,9,21),start,0,true),0);eq(Budget.weekBase(week,LocalDate.of(2026,10,18)),7500);System.out.println(n+" whole-week budget assertions passed");}
}
